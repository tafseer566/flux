$('html, body').css({ 'overflow': 'hidden', 'height': '100%' });
$(window).load(function() {
	$(".preloader").delay(500).fadeOut("slow");
	$('html, body').removeAttr('style');
});